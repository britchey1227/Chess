
public class Knight extends ChessPiece
{
	public Knight(int rank, int file, String fileName)
	{
		super(rank, file);
	}
}
