
public class Queen extends ChessPiece
{
	public Queen(int rank, int file, String fileName)
	{
		super(rank, file);
	}
}
