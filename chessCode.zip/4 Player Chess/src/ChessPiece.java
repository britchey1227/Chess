
public class ChessPiece
{
	protected int rank;
	protected int file;
	protected boolean alive;

	public ChessPiece(int rank, int file)
	{
		this.rank = rank;
		this.file = file;
		alive = true;
	}

	public int getRank()
	{
		return rank;
	}

	public int getFile()
	{
		return file;
	}
	
	public boolean getAlive()
	{
		return alive;
	}
}
