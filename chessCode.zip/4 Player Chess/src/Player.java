
public class Player
{
	// Properties
	private double timer;
	private double timeRemaining;
	
	
	// Constructor
	public Player()
	{
		
	}

	// Methods
	
	
	// Getters and Setters
	public double getTimer()
	{
		return timer;
	}

	public void setTimer(double timer)
	{
		this.timer = timer;
	}

	public double getTimeRemaining()
	{
		return timeRemaining;
	}

	public void setTimeRemaining(double timeRemaining)
	{
		this.timeRemaining = timeRemaining;
	}
	
}
