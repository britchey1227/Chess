
public class Bishop extends ChessPiece
{
	public Bishop(int rank, int file, String fileName)
	{
		super(rank, file);
	}
}
