
public class Rook extends ChessPiece
{
	public Rook(int rank, int file, String fileName)
	{
		super(rank, file);
	}
}
