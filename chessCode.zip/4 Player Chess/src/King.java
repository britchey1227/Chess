
public class King extends ChessPiece
{
	public King(int rank, int file, String fileName)
	{
		super(rank, file);
		//insert jlabel drawing stuff
	}
	
	
}
