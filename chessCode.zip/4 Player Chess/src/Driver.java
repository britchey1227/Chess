import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

public class Driver extends JPanel implements ActionListener, KeyListener, MouseListener, MouseMotionListener
{
	// Window Size
	static final int windowWidth = 1080;
	static final int windowHeight = 1080;

	// Players
	Player red;
	Player blue;
	Player green;
	Player yellow;

	// Containers for Pieces
	ArrayList<ChessPiece> p1Pieces = new ArrayList<ChessPiece>();
	ArrayList<ChessPiece> p2Pieces = new ArrayList<ChessPiece>();
	ArrayList<ChessPiece> p3Pieces = new ArrayList<ChessPiece>();
	ArrayList<ChessPiece> p4Pieces = new ArrayList<ChessPiece>();

	Font font = new Font("Courier New", 1, 25);
	Font font2 = new Font("Courier New", 1, 25);

	// Draws Stuff
	public void paint(Graphics g)
	{
		super.paintComponent(g);

		g.setFont(font);

		// Paints Contents of Arrays
		for (ChessPiece normalBullet : p1Pieces)
		{
			// Check if captured
		}

		for (ChessPiece normalBullet : p2Pieces)
		{
			// Check if captured
		}

		for (ChessPiece normalBullet : p3Pieces)
		{
			// Check if captured
		}

		for (ChessPiece normalBullet : p4Pieces)
		{
			// Check if captured
		}
	}

	public void update()
	{

	}

	@Override
	public void actionPerformed(ActionEvent arg0)
	{
		update();
		repaint();
	}

	public static void main(String[] arg)
	{
		Driver d = new Driver();
	}

	public Driver()
	{
		JFrame f = new JFrame();
		f.setTitle("Chess");
		f.setSize(windowWidth, windowHeight);
		f.setResizable(false);
		f.addKeyListener(this);
		f.addMouseListener(this);

		// Creating Pieces
		King p1King = new King(1, 5, "kingPieceL.png"); // figure out x , y in array
		King p2King = new King(8, 5, "kingPieceD.png");
		Queen p1Queen = new Queen(1, 4, "queenPieceL.png");
		Queen p2Queen = new Queen(8, 4, "queenPieceD.png");
		Bishop p1Bishop6 = new Bishop(1, 6, "bishopPieceL.png");
		Bishop p1Bishop3 = new Bishop(1, 3, "bishopPieceL.png");
		Bishop p2Bishop3 = new Bishop(8, 3, "bishopPieceD.png");
		Bishop p2Bishop6 = new Bishop(8, 6, "bishopPieceD.png");
		Knight p1Knight2 = new Knight(1, 2, "knightPieceL.png");
		Knight p1Knight7 = new Knight(1, 7, "knightPieceL.png");
		Knight p2Knight7 = new Knight(8, 7, "knightPieceD.png");
		Knight p2Knight2 = new Knight(8, 2, "knightPieceD.png");
		Rook p1Rook8 = new Rook(1, 8, "rookPieceL.png");
		Rook p1Rook1 = new Rook(1, 1, "rookPieceL.png");
		Rook p2Rook1 = new Rook(8, 1, "rookPieceD.png");
		Rook p2Rook8 = new Rook(8, 8, "rookPieceD.png");
		Pawn p1Pawn1 = new Pawn(1, 1, "pawnPieceL.png");
		Pawn p1Pawn2 = new Pawn(1, 2, "pawnPieceL.png");
		Pawn p1Pawn3 = new Pawn(1, 3, "pawnPieceL.png");
		Pawn p1Pawn4 = new Pawn(1, 4, "pawnPieceL.png");
		Pawn p1Pawn5 = new Pawn(1, 5, "pawnPieceL.png");
		Pawn p1Pawn6 = new Pawn(1, 6, "pawnPieceL.png");
		Pawn p1Pawn7 = new Pawn(1, 7, "pawnPieceL.png");
		Pawn p1Pawn8 = new Pawn(1, 8, "pawnPieceL.png");
		Pawn p2Pawn1 = new Pawn(1, 1, "pawnPieceD.png");
		Pawn p2Pawn2 = new Pawn(1, 2, "pawnPieceD.png");
		Pawn p2Pawn3 = new Pawn(1, 3, "pawnPieceD.png");
		Pawn p2Pawn4 = new Pawn(1, 4, "pawnPieceD.png");
		Pawn p2Pawn5 = new Pawn(1, 5, "pawnPieceD.png");
		Pawn p2Pawn6 = new Pawn(1, 6, "pawnPieceD.png");
		Pawn p2Pawn7 = new Pawn(1, 7, "pawnPieceD.png");
		Pawn p2Pawn8 = new Pawn(1, 8, "pawnPieceD.png");

		background = new Background("woodFloorBackground.jpg");

		// Keep at Bottom
		f.add(this);
		t = new Timer(17, this);
		t.start();
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);
	}

	Timer t;

	// Movement Control Variables
	boolean w, a, s, d, shoot1n, shoot1f;
	boolean up, down, left, right, shoot2n, shoot2f;

	@Override
	public void keyPressed(KeyEvent e)
	{
		// Player 1 Movement
		switch (e.getKeyCode())
		{
		case 87:
			w = true;
			break;
		case 65:
			a = true;
			break;
		case 83:
			s = true;
			break;
		case 68:
			d = true;
			break;
		case 32:
			shoot1n = true;
			break;
		case 67:
			shoot1f = true;
		}

		// Player 2 Movement
		switch (e.getKeyCode())
		{
		case 38:
			up = true;
			break;
		case 40:
			down = true;
			break;
		case 37:
			left = true;
			break;
		case 39:
			right = true;
			break;
		case 17:
			shoot2n = true;
			break;
		}

		// Prints Key and Code
		System.out.println(e.getKeyChar() + " " + e.getKeyCode());
	}

	@Override
	public void keyReleased(KeyEvent e)
	{
		// Deactivates Key Once Released
		switch (e.getKeyCode())
		{
		case 87:
			w = false;
			break;
		case 65:
			a = false;
			break;
		case 83:
			s = false;
			break;
		case 68:
			d = false;
			break;
		case 38:
			up = false;
			break;
		case 40:
			down = false;
			break;
		case 37:
			left = false;
			break;
		case 39:
			right = false;
			break;
		case 32:
			shoot1n = false;
			break;
		case 67:
			shoot1f = false;
			break;
		case 17:
			shoot2n = false;
			break;
		}
	}

	@Override
	public void mouseClicked(MouseEvent e)
	{
		System.out.println(e.getComponent().getClass());
		// Sprite s = new Sprite("player.png", e.getX(),e.getY());

		// sprites.add(s);

		if (e.getComponent().getClass() == Tank.class)
		{
			System.out.println("clicked on a sprite");
		}

	}

	@Override
	public void mouseDragged(MouseEvent arg0)
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseMoved(MouseEvent arg0)
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent arg0)
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent arg0)
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent arg0)
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent arg0)
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void keyTyped(KeyEvent e)
	{
		// TODO Auto-generated method stub

	}
}
