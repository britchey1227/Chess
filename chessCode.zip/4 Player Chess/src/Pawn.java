
public class Pawn extends ChessPiece
{
	public Pawn(int rank, int file, String fileName)
	{
		super(rank, file);
	}
}
